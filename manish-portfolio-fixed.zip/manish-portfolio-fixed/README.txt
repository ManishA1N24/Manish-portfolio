MANISH GUPTA PORTFOLIO — STANDALONE VERSION

This version is intentionally dependency-free and works by double-clicking index.html.
No npm install, React, Vite, or internet connection is required.

Open:
index.html

For deployment, upload index.html to GitHub Pages, Netlify, Vercel, or any static hosting service.
